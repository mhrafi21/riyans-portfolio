<div class="vlog-cover">
	<?php echo vlog_get_featured_image('vlog-cover-full', false, false, true ); ?>
</div>