<?php if ( function_exists('meks_ess_share') ) : ?>

	<div class="vlog-share-single">
		<?php meks_ess_share(); ?>
	</div>

<?php endif; ?>