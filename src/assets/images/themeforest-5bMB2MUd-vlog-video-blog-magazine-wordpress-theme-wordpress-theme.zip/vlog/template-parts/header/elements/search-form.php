<li class="vlog-actions-search">
	<?php get_search_form(); ?>
</li>