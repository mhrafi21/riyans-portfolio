<li class="vlog-actions-button vlog-action-search">
	<span>
		<i class="fv fv-search"></i>
	</span>
	<ul class="sub-menu">
		<?php get_search_form(); ?>
	</ul>
</li>